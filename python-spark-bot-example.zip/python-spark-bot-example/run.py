from app import app
# If you need to make the application visible outside, change the
# ip address to your own ip. You can also change the port that
# the application will be listening.
app.run(host='localhost', debug=True, port=8080)
