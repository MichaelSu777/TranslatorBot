import flask_sijax
import json
import requests
from app import app
from flask import request
from googletrans import Translator


@flask_sijax.route(app, '/')


def hello():
    data = json.loads(request.data)
    url = "https://api.ciscospark.com/v1/messages/" + data["data"]["id"]
	
    if (data["data"]["personEmail"] != 'languagetranslator@webex.bot'):
        headers = {
            'Content-type': "application/json; charset=utf-8",
            'Authorization': "Bearer YzVmNjA0MzYtNzkxMS00NmI5LWFiYzctMmJlYzIwZmI2OTUyMmY2YWUzYTYtNjVj",
        }

        response = requests.request("GET", url, headers=headers)

        message = json.loads(response.text)
		
        print(message["text"])

        translator = Translator();
        langs = translator.detect([message["text"]])
		
        #gets rid of @translatorbot
        splitText = message["text"].split("TranslatorBot")[0]

        #splits input text into an array of words
        arrayWords = splitText.split()
		
        print(langs) 
		
		

        if message["text"] == "TranslatorBot /help":
            payload = {
                "roomId": data["data"]["roomId"],
                "text": "Thank you for chosing TranslatorBot! This is how I work: \n\n" +
                        "/trans text to be translated xx : where xx == destination language. For example: \n" +
                "\"TranslatorBot /trans hello friend es\" will repond with\n" +
                "hola amigo\n\n" +
                "For a list of languages, please visit this documentation https://cloud.google.com/translate/docs/languages"#type stuff that you want here for help function
            }
        elif message["text"] == message["text"] :
			messagetext = message["text"]
			lang = messagetext[-2:]
			finalmessage = messagetext[:-2]
			finalmessage2 = finalmessage[21:]
			destlang = str(lang)
			#try: 
				#finalsplitText = splitText.split("/trans")[1]
				#translation = translator.translate(finalsplitText.split(arrayWords[1])[1], dest=arrayWords[1])
				#translation = translator.translate(arrayWords[0], )
				#for lang in langs:
				#	print(lang.lang, lang.confidence)

				#print(translation.origin, ' -> ', translation.text)
			translation = translator.translate(finalmessage2, dest=lang)
			payload = {
				"roomId": data["data"]["roomId"],
				"text": translation.text
			}
			#except OSError:
			#	print('cannot open', arg)
			#else:
			#	payload = {
			#		"roomId": data["data"]["roomId"],
			#		"text": "Sorry, translation failed"
			#	}
        else :
            payload = {
                "roomId": data["data"]["roomId"],
                "text": "type /help for information"
            }


        replyUrl = "https://api.ciscospark.com/v1/messages/"
        requests.request("POST", replyUrl, data=json.dumps(payload), headers=headers)

        return 'OK'
