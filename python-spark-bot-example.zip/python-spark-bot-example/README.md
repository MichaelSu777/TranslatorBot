# Spark bot example - Python

This is a simple bot that reads a message and then replies with "Got it!"


## Run from the Command line

Run run.py using the following command

```shell
> pip install -r requirements.txt
> python run.py
